import { Component } from '@angular/core';

@Component({
    selector: "viewAllTicket",
    template: ``
})

export class ViewAllTickets {
    
}
