import { Component } from '@angular/core';
import { LoginService } from './services/login.service';
import { LoginComponent } from './login.component';

@Component({
    selector: 'my-app',
    // Without bootstrap
   /* template: `<h3>Issue Management System</h3>
    <router-outlet></router-outlet>`, */
    

    //with bootstrap
    template: `<div class="jumbotron" class="text-center">
                    <h2>Issue Management System</h2>
                </div>
                <router-outlet></router-outlet>`, 
    providers: [LoginService]


})

export class AppComponent {

}
