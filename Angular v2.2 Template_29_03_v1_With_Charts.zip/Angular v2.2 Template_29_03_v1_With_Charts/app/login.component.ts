
import { Component } from '@angular/core';
import { LoginService } from './services/login.service';
import { Router } from '@angular/router';

@Component({
    selector: 'login-template',
    moduleId: module.id,
     templateUrl: 'login.component.html'

})

export class LoginComponent {
    loginObj = {
        userName: "",
        password: ""
    }

    responseData: any;

    constructor(private loginService: LoginService, private router: Router) {
    }

    onSubmit(userData: object) {
        this.responseData = this.loginService.getLoginInfo(userData);
        console.log("loginService :" + JSON.stringify(this.responseData));

        if (this.responseData && this.responseData.role == 'user') {
            this.router.navigate(['/user']);
        } else if (this.responseData && this.responseData.role == 'admin') {
            this.router.navigate(['/admin']);
        };

        // this.loginService.getLoginInfo(userData)
        // .subscribe(response => this.responseData = response);
        // console.log("loginService :", this.responseData)


    }



}