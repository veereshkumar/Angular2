import { Component } from '@angular/core';
import {Router} from '@angular/router';

@Component({
    selector: 'user-template',
    template: `<h3>User Template<h3> 
    <input id="search" type="search" #search placeholder="Search by Ticket ID" /> 
    <button (click)="onSearch(search.value)">Search</button>
    <br><br><br>
     <button (click)="onCreateTicket()">Create Ticket</button>
     <button (click)="onViewAllTicket()">View All Tickets</button>`

})

export class UserComponent {

   constructor(private router: Router){}

   onSearch(searchValue:string){
       console.log("searchValue :",searchValue)
   }

   onCreateTicket(){
    this.router.navigate(['/user/createTicket']);
   }

   onViewAllTicket(){
    this.router.navigate(['/user/viewAllTickets']);
   }




}