import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import {RouterModule} from '@angular/router';
import { HttpModule } from '@angular/http';

import { AppComponent }  from './app.component';
import {LoginComponent} from './login.component';
import {UserComponent} from './user.component';
import {AdminComponent} from './admin.component';
import {UserCreateTicket} from './user.createTicket.component';

@NgModule({
  imports:      [ BrowserModule,FormsModule,HttpModule,
  RouterModule.forRoot([
    {path:"", component:LoginComponent},
    {path:"user", component:UserComponent},
    {path:"admin", component:AdminComponent},
    {path:"user/createTicket", component:UserCreateTicket}

  ])  ],
  declarations: [ AppComponent,LoginComponent,UserComponent, AdminComponent, UserCreateTicket ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
