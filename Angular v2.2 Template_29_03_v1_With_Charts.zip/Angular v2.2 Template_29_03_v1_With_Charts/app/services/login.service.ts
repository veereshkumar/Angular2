import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Observable } from 'rxjs/Rx';

@Injectable()
export class LoginService {
  constructor(private http: Http) { }

  //private commentsUrl = 'http://localhost:3000/api/comments';

  getLoginInfo(userData: Object): any {
    // TODO: Call the login service 
    // console.log("login Data req:",userData)
    var obj = {
      message: "sucess",
      role: 'user'  // user, admin
    };
    return obj;

    /*  let postBody = userData;
  
      let bodyString = JSON.stringify(postBody); 
      let headers = new Headers({ 'Content-Type': 'application/json' }); 
      let options = new RequestOptions({ headers: headers }); 
  
      return this.http.post(this.loginUrl, postBody, options) 
        .map((res: Response) => res.json()) //calling .json() on the response to return data
        .catch((error: any) => Observable.throw(error.json().error || 'Server error'));
        */
  }
}    
