

import { Component } from '@angular/core';

@Component({
    selector: 'user-template',
    template: `<h3>Admin Template<h3> `

})

export class AdminComponent {


}