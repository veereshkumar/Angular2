import { Component } from '@angular/core';

@Component({
    selector: "createTicket",
    template: `
    Issue Type
    <select>
        <option value="">Select</option>
    </select>
    <br><br>
    Comments <textarea rows="3" cols="20"></textarea>
    <br><br>
    <button (click)="onCreateTicket">Create</button>`
})

export class UserCreateTicket {
    onCreateTicket() {

    }
}
