
var express = require('express');
var app = express();
var bodyparser = require('body-parser');

app.use(bodyparser.json());

app.post('/test',function(req,res){
	
	response = req.body;
	response.message = "Message from NodeJS Server POST Method";
	//res.header("Access-Control-Allow-Origin", "*");
    //res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
	
	// Website you wish to allow to connect
    res.setHeader('Access-Control-Allow-Origin', '*');
    // Request methods you wish to allow
    //res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');
	
	console.log("Post Method"+JSON.stringify(response));
	res.json(response)
})


app.get('/test',function(req,res){
	console.log("Get Method");
	response = {}
	response.message = "Message from NodeJS Server GET Method";
	
	res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
	res.json( response)
})

app.listen(3005,function(err,res){
	if(err){
		console.log("Error while starting the server")
	}
	
	console.log("Sever is listing at port 3005")
})