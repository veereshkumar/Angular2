
import { Component, OnInit } from '@angular/core';
import { LoginService } from './services/login.service';
import { Router } from '@angular/router';

@Component({
    selector: 'login-template',
    moduleId: module.id,
    templateUrl: 'login.component.html'

})

export class LoginComponent implements OnInit {
    loginObj = {
        userName: "",
        password: "",
        severity: "",
        viewLogData: "",
        issueID: ""
    }

    responseData: Object;

    public severityList = ["High", "Midium", "Low"];
    //public severitySelectedValue = "Low";

    //loginObj.severity = "Low";

    constructor(private loginService: LoginService, private router: Router) {
    }

    ngOnInit() {
        this.loginObj.severity = "Midium";
        this.loginObj.viewLogData = "This is sample Log data for pop testing";
        this.loginObj.issueID = "101";
    }

    onSubmit(userData: object) {
        /*   this.responseData = this.loginService.getLoginInfo(userData);
           console.log("loginService :" + JSON.stringify(this.responseData));
   
           if (this.responseData && this.responseData.role == 'user') {
               this.router.navigate(['/user']);
           } else if (this.responseData && this.responseData.role == 'admin') {
               this.router.navigate(['/admin']); 
            }*/


        console.log("Calling login service");
        //alert("Form submitted sucessfully!")


        // Get Service
        this.loginService.getLoginInfo(userData)
            // .subscribe(response => this.responseData = response);
            .subscribe(function (response) {
                this.responseData = response
                console.log("Calling login service222 " + JSON.stringify(this.responseData));
            })


    };

    //fileUpload

    fileChange(event: any) {
        let fileList: FileList = event.target.files;
        if (fileList.length > 0) {
            let file: File = fileList[0];
            let formData: FormData = new FormData();
            formData.append('uploadFile', file, file.name);
            console.log("file :",file);
            console.log("formData :",formData);

            let headers = new Headers();
            headers.append('Content-Type', 'multipart/form-data');
            headers.append('Accept', 'application/json');
           /* let options = new RequestOptions({ headers: headers });
                this.http.post(`${this.apiEndPoint}`, formData, options)
                    .map(res => res.json())
                    .catch(error => Observable.throw(error))
                    .subscribe(
                    data => console.log('success'),
                    error => console.log(error)
                    ) */
        }
    }



}



