
import {Component} from 'angular2/core';
import {bootstrap} from 'angular2/platform/browser';
import {HTTP_BINDINGS} from 'angular2/http';
import {Userform} from './Userform';

@Component({ // componet decorator+class
    selector:"my-app",
    template:`<h1>My Angular 2 App<h1>
    <userform></userform>`,
    //<userform></userform>`,
    directives:[Userform]

})

export class AppComponent{ }
bootstrap(AppComponent,[// main 
    HTTP_BINDINGS
]).catch(console.error);

