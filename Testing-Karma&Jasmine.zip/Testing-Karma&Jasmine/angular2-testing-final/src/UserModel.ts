export class UserModel{
    firstName:string;
    age:string;
    gender:string;
    skills=[];
}