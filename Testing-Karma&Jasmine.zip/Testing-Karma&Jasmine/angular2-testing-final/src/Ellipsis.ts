import {PipeTransform, Pipe} from 'angular2/core';

@Pipe({name:'ellipsis'})
export class Ellipsis implements PipeTransform{
    transform(text:string,config:any[]):any{
        //if(text && text.length>5){
            //return text.substr(0,5)+"..."
        if(text && text.length>config[0]){ // config[0] = 4, config[1]='*'
            return text.substr(0,5)+config[1]+config[1]+config[1];
        }
        return text;
    }
}