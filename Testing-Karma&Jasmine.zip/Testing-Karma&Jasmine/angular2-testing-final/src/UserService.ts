
import { Injectable } from 'angular2/core';
import { Http } from 'angular2/http';
import {UserModel} from './UserModel';

@Injectable()
export class UserService{
    constructor(public http:Http) {

    }
    save(user:UserModel):any {
        //var observable = this.http.get("SomeURL");
        // observable.subscribe(function () { // first function is sucess
        //     console.log("Sucess");  
        // }, function () {            // Second function is sucess
        //     console.log("Error");
        // })
        console.log("Save Service is called")
        var observable = this.http.post('someURL', JSON.stringify(user));
        return observable;

        
    }

    delete(index:String){
        console.log("Delete Service is called")
        var observable = this.http.delete('deleteURL',index);
        return observable;
    }
}