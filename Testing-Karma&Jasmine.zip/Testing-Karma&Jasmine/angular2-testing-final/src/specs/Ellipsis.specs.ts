
/// <reference path="../../typings/main/ambient/jasmine/jasmine.d.ts"/>

import { Ellipsis } from '../Ellipsis'
import {
    it, xit,
    describe,
    expect,
    TestComponentBuilder,
    inject, injectAsync,
    setBaseTestProviders,
    beforeEachProviders
} from 'angular2/testing';

describe('testing Ellipsis pipe', function () { // Testing each method
    it('testing positive scenario', function () { // Testing each scenario
        console.log("Testing is awsome");
        expect(true).toEqual(false);

        let pipe: Ellipsis = new Ellipsis(); // let us used to define a constant
        let result = pipe.transform("Veeresh", [4, "."]);
        expect("Rame...").toEqual(result);
    });

    // it('testing transform("Ramesh",[7,"."]', function () { // Testing each scenario
    //     let pipe: Ellipsis = new Ellipsis(); // let us used to define a constant
    //     let result = pipe.transform("Veeresh", [8, "."]);
    //     expect("Veeresh").toEqual(result);
    // });
    // it('testing transform("Ramesh",[]', function () { // Testing each scenario
    //     let pipe: Ellipsis = new Ellipsis(); // let us used to define a constant
    //     let result = pipe.transform("Veeresh", [4]);
    //     expect("Rame...").toEqual(result);
    // });
});