
import { Component } from 'angular2/core';
import { UserModel } from './UserModel';
import { UserService } from './UserService';
import {Ellipsis} from './Ellipsis';

@Component({
    selector: "userform",
    template: `Name:<input [(ngModel)]='user.firstName'/> 
    Age:<input type='number' [(ngModel)]='user.age'/> 
    <input #male [ngModel]='user.gender' name="gender" type="radio" 
        value="Male" (click)="user.gender = male.value"/>Male
    <input #female [ngModel]='user.gender' name="gender" type="radio" 
        value="Female" (click)="user.gender = female.value"/>Female 
  
   
    <button (click)='save()'>Save</button>
    <ol><li *ngFor='#i=index,#user of users'>
        {{user.firstName| uppercase | ellipsis:4:'*'}},{{user.age}},{{user.gender}} 
        <button (click)='delete(i)'>Delete</button>
    <li></ol>`,
    providers: [UserService],
    pipes:[Ellipsis]
})

export class Userform { // Controller

    private users: UserModel[] = [];
    private user: UserModel = new UserModel();
    constructor(public userService: UserService) {
        this.user.firstName = "";
    }

    save() {
        var observable = this.userService.save(Object.assign({}, this.user));
        observable.subscribe(function () { // first function is sucess
            console.log("Save Sucess");
        }, function () {            // Second function is sucess
            console.log("Save Error",arguments);
        })

        console.log(this.user.firstName + ' is working and age: ' + this.user.age + " gender:" + this.user.gender);
        // this.users.push(Object.assign({},this.user)); // Alternate way
        this.users.push(this.user);
        this.user = new UserModel();
    }

    delete(index) {
        console.log("Index = "+index)
        this.users.splice(index, 1); // delete in UI side - comment this when u integrated with server
        var observable = this.userService.delete(index);
        observable.subscribe(function () { // first function is sucess
            console.log("Delete Sucess");
        }, function () {            // Second function is sucess
            console.log("Delete Error",arguments);
        })

        
       
    }
}
